#pragma once

#include <stdio.h>
/*
 * A Hello class instance can say hello and goodbye.
 * Note the __declspec(dllexport) directive. This is required so that the library
 * exports the class interfaces. Without this you will not be able to link to the
 * library. Notably it won't produce a hello.lib file, but only the dll.
 */
class __declspec(dllexport) MiniAudio
{
	public:
		void init(void);
		void destroy(void);
		void start(void);
		void stop(void);
		double getPlaybackPosition(void);
		void seekToPCMFrame(int64_t);
		void loadFiles(int, const char**);
		void deactivate_decoder(int);
};