#include <stdio.h>

void init(void);
void destroy(void);
void start(void);
void stop(void);
double getPlaybackPosition(void);
void seekToPCMFrame(int64_t);
void loadFiles(int, const char**);
void deactivate_decoder(int);